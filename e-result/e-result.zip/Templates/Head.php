
<?php include_once ("MetaTags.php");?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet">
<!-- local devlopement -->
 <link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css"> 
<style>
.card-registration{
font-size: 1rem;
line-height: 1.15;
padding-left: .75em;
padding-right: .75em;
}
.card-registration .select-arrow {
top: 10px;
}
label {
  margin-bottom: 13px;
}
</style>
