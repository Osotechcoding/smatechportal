<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <meta name="description" content="<?php echo ($Osotech->getConfigData()->school_name);?>,Online School Portal,<?php echo ($Osotech->getConfigData()->school_slogan);?>, Affordable School Fee,Online Admission Process">
    <meta name="keywords" content="Elementary School, Basic Classes, Primary classes, College, Staff Portal, Student Portal, Admin Portal, Online Admission Online Result Checker">
    <meta name="author" content="<?php echo ucwords(__OSOTECH__DEV_COMPANY__);?>">
    <link rel="icon" type="image/icon" href="<?php echo $Osotech->get_schoolLogoImage();?>">
