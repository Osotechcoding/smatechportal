<footer class="py-1 my-2 text-center osotech-bg-color">
    <ul class="nav justify-content-center border-bottom pb-3 mb-3">
      <li class="nav-item"><a href="#" class="nav-link px-2 text-muted">Home</a></li>
      <li class="nav-item"><a href="#" class="nav-link px-2 text-muted">Scratch Card</a></li>
      <li class="nav-item"><a href="../documentation/v1/#Content" target="_blank" class="nav-link px-2 text-muted">Documentation</a></li>
    </ul>
    <p class="text-center text-muted">&copy; <script>
      document.write(new Date().getFullYear());
    </script> Alright Reserved || <span class="text-danger">Developer: <?php echo __OSO_DEV_COMPANY__; ?></span>  </p>
  </footer>
