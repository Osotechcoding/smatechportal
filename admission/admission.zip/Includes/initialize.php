<?php
if (!defined("__OSO_DEV_COMPANY__")) {
	define("__OSO_DEV_COMPANY__", "Osotech");
	define("__OSO_HOST__",'localhost');
	define("__OSO_USER__",'root');
	define("__OSO_PASS__",'osotech');
	define("__OSO_DBNAME__",'smatech_portal');
	/*define("__OSO_USER__",'smatechportal_admin');
	define("__OSO_PASS__",'@smatech');*/
	define("__OSO_SCHOOL_CODE__","C24314");
	define("__OSO_DB_DRIVER__",'mysql');
	define("__OSO_CHARSET__",'utf8mb4');
	define("__OSO_APP_DEV_YEAR__","2020");
	define("__OSO_APP_NAME__","SMATECH");
	define("ADMISSION_PORTAL_ROOT","http://localhost/smatechportal/admission/");
	define("APP_ROOT","http://localhost/smatechportal/");
	define("EPORTAL_ROOT","http://localhost/smatechportal/eportal/");
	//define("EPORTAL_ROOT","https://smatechportal.com/eportal/");
	//define("APP_ROOT","https://smatechportal.com/");
	//define("ADMISSION_PORTAL_ROOT","https://admission.smatechportal.com/");

}
